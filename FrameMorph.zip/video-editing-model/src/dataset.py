import os
import torch
from torch.utils.data import Dataset
from torchvision.transforms import Compose, Resize, ToTensor
import cv2
from PIL import Image
from transformers import CLIPProcessor, CLIPModel

class VideoEditingDataset(Dataset):
    def __init__(self, video_dir, annotation_file, transform=None, device="cpu"):
        """
        Args:
            video_dir (str): Path to the folder containing videos.
            annotation_file (str): Path to the annotations file.
            transform (callable, optional): Transform to apply to video frames.
            device (str): Device to use ("cpu" or "cuda").
        """
        self.video_dir = video_dir
        self.annotations = self._load_annotations(annotation_file)
        self.transform = transform
        self.device = device

        # Load pre-trained CLIP model and move to device
        self.clip_model = CLIPModel.from_pretrained("openai/clip-vit-base-patch32").to(self.device)
        self.clip_processor = CLIPProcessor.from_pretrained("openai/clip-vit-base-patch32")

    def _load_annotations(self, annotation_file):
        """Load video-prompt pairs from the annotation file."""
        with open(annotation_file, 'r') as f:
            lines = f.readlines()
        annotations = [line.strip().split('|') for line in lines]
        return annotations

    def __len__(self):
        return len(self.annotations)

    def __getitem__(self, idx):
        video_file, prompt = self.annotations[idx]
        video_path = os.path.join(self.video_dir, video_file)

        # Load video frames
        cap = cv2.VideoCapture(video_path)
        frames = []
        while True:
            ret, frame = cap.read()
            if not ret:
                break
            frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)  # Convert to RGB
            frame = Image.fromarray(frame)  # Convert NumPy array to PIL Image
            if self.transform:
                frame = self.transform(frame)
            frames.append(frame)
        cap.release()

        frames = torch.stack(frames).to(self.device)  # Move frames to the device

        # Generate text embeddings using CLIP and move to device
        inputs = self.clip_processor(text=prompt, return_tensors="pt", padding=True).to(self.device)
        with torch.no_grad():
            text_embedding = self.clip_model.get_text_features(**inputs)

        return frames, text_embedding.squeeze(0)
