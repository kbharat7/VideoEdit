import os
import torch
from torchvision.transforms import Compose, Resize, ToTensor
from PIL import Image
import cv2
import sys
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from src.model import VideoEditingModel
from src.dataset import VideoEditingDataset


def apply_zoom(frames, zoom_factor):
    """
    Applies zoom effect to the frames.
    Args:
        frames (torch.Tensor): Video frames, shape (num_frames, 3, H, W).
        zoom_factor (float): Zoom factor to apply.
    Returns:
        torch.Tensor: Zoomed frames, shape (num_frames, 3, H, W).
    """
    zoomed_frames = []
    _, C, H, W = frames.size()  # Correctly unpack shape (num_frames, C, H, W)
    new_H, new_W = int(H * zoom_factor), int(W * zoom_factor)

    for frame in frames:
        # Resize the frame
        frame = torch.nn.functional.interpolate(frame.unsqueeze(0), size=(new_H, new_W), mode="bilinear").squeeze(0)
        # Center crop or pad to original size
        if zoom_factor > 1:  # Zoom in
            frame = frame[:, :H, :W]
        else:  # Zoom out
            pad_H = (H - new_H) // 2
            pad_W = (W - new_W) // 2
            frame = torch.nn.functional.pad(frame, (pad_W, pad_W, pad_H, pad_H))
        zoomed_frames.append(frame)

    return torch.stack(zoomed_frames)


# Load the trained model
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model = VideoEditingModel().to(device)
model.load_state_dict(torch.load("results/video_editing_model.pth"))
model.eval()
print("Model loaded successfully.")

# Define paths
video_dir = "data/videos"
annotation_file = "data/annotations.txt"

# Define dataset
transform = Compose([
    Resize((128, 128)),  # Resize frames to 128x128
    ToTensor(),          # Convert PIL image to PyTorch tensor
])
dataset = VideoEditingDataset(video_dir, annotation_file, transform=transform, device=device)

# Iterate over all videos in the dataset
for video_idx in range(len(dataset)):
    frames, text_embedding = dataset[video_idx]
    video_file = dataset.annotations[video_idx][0]

    # Predict the zoom factor
    with torch.no_grad():
        predicted_zoom = model(frames.unsqueeze(0), text_embedding.unsqueeze(0)).item()
    print(f"Processing video: {video_file}, Predicted zoom factor: {predicted_zoom}")

    # Apply zoom effect
    zoomed_frames = apply_zoom(frames, predicted_zoom)

    # Save the zoomed video
    output_path = os.path.join("results", f"zoomed_{video_file}")
    fourcc = cv2.VideoWriter_fourcc(*'mp4v')
    out = cv2.VideoWriter(output_path, fourcc, 20.0, (128, 128))

    for frame in zoomed_frames:
        frame_np = (frame.permute(1, 2, 0).cpu().numpy() * 255).astype("uint8")  # Convert to NumPy array
        out.write(cv2.cvtColor(frame_np, cv2.COLOR_RGB2BGR))

    out.release()
    print(f"Zoomed video saved to {output_path}")
