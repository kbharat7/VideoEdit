import torch
import torch.nn as nn

class VideoEditingModel(nn.Module):
    def __init__(self, frame_dim=512, text_dim=512, hidden_dim=256):
        super(VideoEditingModel, self).__init__()

        # Frame Encoder: CNN
        self.frame_encoder = nn.Sequential(
            nn.Conv2d(3, 64, kernel_size=3, stride=1, padding=1),
            nn.ReLU(),
            nn.MaxPool2d(kernel_size=2, stride=2),
            nn.Conv2d(64, 128, kernel_size=3, stride=1, padding=1),
            nn.ReLU(),
            nn.AdaptiveAvgPool2d((1, 1)),
        )
        self.frame_fc = nn.Linear(128, frame_dim)

        # Temporal Encoder: GRU
        self.temporal_model = nn.GRU(frame_dim, hidden_dim, batch_first=True)

        # Text Encoder: CLIP's text embeddings are used directly
        self.text_fc = nn.Linear(text_dim, hidden_dim)

        # Decoder: Combine text and frame features to predict zoom factor
        self.fc = nn.Linear(hidden_dim, 1)  # Predict zoom factor (1.0 = no zoom, <1 = zoom out, >1 = zoom in)

    def forward(self, frames, text_embedding):
        # Encode video frames
        batch_size, num_frames, C, H, W = frames.size()
        frames = frames.view(-1, C, H, W)  # Flatten batch and frames
        frame_features = self.frame_encoder(frames)
        frame_features = frame_features.view(batch_size, num_frames, -1)  # Reshape back to (batch, frames, features)
        frame_features = self.frame_fc(frame_features)

        # Encode temporal relationships
        temporal_features, _ = self.temporal_model(frame_features)

        # Encode text and combine
        text_features = self.text_fc(text_embedding)
        combined_features = temporal_features[:, -1, :] + text_features

        # Predict zoom factor
        zoom_factor = self.fc(combined_features)
        return torch.sigmoid(zoom_factor) + 1  # Scale output to (1, 2) for zooming
