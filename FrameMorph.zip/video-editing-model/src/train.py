import os
import torch
import torch.nn as nn  # Import nn module from PyTorch
from torch.utils.data import DataLoader
import sys
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from src.dataset import VideoEditingDataset
from src.model import VideoEditingModel
from torchvision.transforms import Compose, Resize, ToTensor
from torch.optim import Adam
from tqdm import tqdm

# Check if GPU is available
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(f"Using device: {device}")

# Paths
video_dir = os.path.join("data", "videos")
annotation_file = os.path.join("data", "annotations.txt")

# Define dataset and dataloader
transform = Compose([
    Resize((128, 128)),  # Resize frames to 128x128
    ToTensor(),          # Convert PIL image to PyTorch tensor
])
dataset = VideoEditingDataset(video_dir, annotation_file, transform=transform, device=device)
dataloader = DataLoader(dataset, batch_size=1, shuffle=True)

# Initialize model
model = VideoEditingModel().to(device)

# Define optimizer and loss function
optimizer = Adam(model.parameters(), lr=1e-4)
criterion = nn.MSELoss()  # Correctly import and define the criterion

# Training loop
epochs = 10
for epoch in range(epochs):
    model.train()
    epoch_loss = 0
    for frames, text_embedding in tqdm(dataloader):
        frames, text_embedding = frames.to(device), text_embedding.to(device)
        true_zoom = torch.tensor([1.5]).to(device)  # Dummy label for now (replace with actual labels if available)

        # Forward pass
        predicted_zoom = model(frames, text_embedding)
        loss = criterion(predicted_zoom, true_zoom)

        # Backward pass
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        epoch_loss += loss.item()

    print(f"Epoch {epoch + 1}/{epochs}, Loss: {epoch_loss / len(dataloader)}")
    # Save the model
save_path = "results/video_editing_model.pth"
torch.save(model.state_dict(), save_path)
print(f"Model saved to {save_path}")


